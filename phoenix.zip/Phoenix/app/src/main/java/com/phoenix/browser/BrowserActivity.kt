package com.phoenix.browser

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.ByteArrayInputStream

class BrowserActivity : AppCompatActivity() {

    private class Tab(val web: WebView, val incognito: Boolean) {
        var title = "Yeni sekme"
        var url = ""
    }

    private val tabs = mutableListOf<Tab>()
    private var cur = -1
    private var nightMode = false
    private var adBlock = true
    private var pendingMedia: String? = null
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    private lateinit var urlBar: EditText
    private lateinit var tabsBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var container: FrameLayout
    private lateinit var homeView: View
    private lateinit var downloadBtn: Button

    private val shortcuts = listOf(
        "Google" to "https://www.google.com",
        "YouTube" to "https://m.youtube.com",
        "Vikipedi" to "https://tr.wikipedia.org",
        "Yandex" to "https://yandex.com.tr",
        "Facebook" to "https://m.facebook.com",
        "X" to "https://x.com",
        "Instagram" to "https://www.instagram.com",
        "GitLab" to "https://gitlab.com",
        "Haberler" to "https://news.google.com"
    )

    private val blockedHosts = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adnxs.com", "taboola.com", "outbrain.com",
        "popads.net", "propellerads.com", "exoclick.com", "adsterra.com",
        "criteo.com", "pubmatic.com", "rubiconproject.com", "openx.net",
        "scorecardresearch.com", "moatads.com", "mgid.com", "revcontent.com"
    )

    private val mediaExt = listOf(".mp4", ".webm", ".mp3", ".m4a", ".ogg", ".wav", ".flac")

    private val nightOn = "(function(){var s=document.getElementById('phx-night');" +
        "if(!s){s=document.createElement('style');s.id='phx-night';document.documentElement.appendChild(s);}" +
        "s.textContent='html{filter:invert(1) hue-rotate(180deg)!important;background:#fff}" +
        " img,video,picture,canvas,iframe{filter:invert(1) hue-rotate(180deg)!important}';})();"
    private val nightOff = "(function(){var s=document.getElementById('phx-night');if(s)s.remove();})();"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)

        urlBar = findViewById(R.id.urlBar)
        tabsBtn = findViewById(R.id.tabsBtn)
        progress = findViewById(R.id.progress)
        container = findViewById(R.id.webContainer)
        homeView = findViewById(R.id.homeView)
        downloadBtn = findViewById(R.id.downloadBtn)

        buildHome()

        urlBar.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                go(urlBar.text.toString())
                true
            } else false
        }
        tabsBtn.setOnClickListener { showTabs() }
        findViewById<Button>(R.id.menuBtn).setOnClickListener { showMenu(it) }
        downloadBtn.setOnClickListener {
            pendingMedia?.let { startDownload(it, null, null, null) }
            downloadBtn.visibility = View.GONE
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = onBack()
        })

        if (Build.VERSION.SDK_INT <= 28 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }

        newTab(intent?.data?.toString(), false)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.data?.let { newTab(it.toString(), false) }
    }

    override fun onDestroy() {
        if (tabs.any { it.incognito }) wipeData()
        tabs.forEach { it.web.destroy() }
        super.onDestroy()
    }

    private fun tab(): Tab = tabs[cur]

    // ---------- Ana sayfa ----------
    private fun buildHome() {
        val grid = findViewById<GridLayout>(R.id.homeGrid)
        val colors = intArrayOf(
            0xFFE53935.toInt(), 0xFFFB8C00.toInt(), 0xFF43A047.toInt(),
            0xFF1E88E5.toInt(), 0xFF8E24AA.toInt(), 0xFF00ACC1.toInt()
        )
        val size = (56 * resources.displayMetrics.density).toInt()
        shortcuts.forEachIndexed { i, (name, url) ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(8, 24, 8, 24)
            }
            val icon = TextView(this).apply {
                text = name.first().toString()
                setTextColor(Color.WHITE)
                textSize = 22f
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(colors[i % colors.size])
                }
            }
            cell.addView(icon, LinearLayout.LayoutParams(size, size))
            cell.addView(TextView(this).apply {
                text = name
                gravity = Gravity.CENTER
                setPadding(0, 8, 0, 0)
            })
            cell.setOnClickListener { go(url) }
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED),
                GridLayout.spec(GridLayout.UNDEFINED, 1f)
            )
            lp.width = 0
            grid.addView(cell, lp)
        }
    }

    // ---------- Sekmeler ----------
    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String?, incognito: Boolean) {
        val w = WebView(this)
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            builtInZoomControls = true
            displayZoomControls = false
            loadWithOverviewMode = true
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = if (incognito) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        }
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url.toString()
                if (u.startsWith("http://") || u.startsWith("https://") || u.startsWith("about:")) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, r.url)) } catch (_: Exception) {}
                return true
            }

            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val host = r.url.host ?: ""
                if (adBlock && blockedHosts.any { host == it || host.endsWith(".$it") }) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                val path = (r.url.path ?: "").lowercase()
                if (mediaExt.any { path.endsWith(it) }) {
                    val u = r.url.toString()
                    runOnUiThread {
                        if (tabs.getOrNull(cur)?.web === v) {
                            pendingMedia = u
                            downloadBtn.visibility = View.VISIBLE
                        }
                    }
                }
                return null
            }

            override fun onPageStarted(v: WebView, url: String, favicon: android.graphics.Bitmap?) {
                val t = tabs.firstOrNull { it.web === v } ?: return
                t.url = if (url == "about:blank") "" else url
                if (t === tabs.getOrNull(cur)) {
                    pendingMedia = null
                    downloadBtn.visibility = View.GONE
                    updateUi()
                }
            }

            override fun onPageFinished(v: WebView, url: String) {
                tabs.firstOrNull { it.web === v }?.let { it.title = v.title ?: url }
                if (nightMode) v.evaluateJavascript(nightOn, null)
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (v === tabs.getOrNull(cur)?.web) {
                    progress.progress = p
                    progress.visibility = if (p < 100) View.VISIBLE else View.GONE
                }
            }

            override fun onReceivedTitle(v: WebView, title: String?) {
                tabs.firstOrNull { it.web === v }?.title = title ?: ""
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) { callback.onCustomViewHidden(); return }
                customView = view
                customCb = callback
                (window.decorView as FrameLayout).addView(
                    view, FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
                    )
                )
                WindowInsetsControllerCompat(window, window.decorView)
                    .hide(WindowInsetsCompat.Type.systemBars())
            }

            override fun onHideCustomView() = hideCustom()
        }
        w.setDownloadListener { u, ua, cd, mime, _ -> startDownload(u, ua, cd, mime) }
        w.visibility = View.GONE
        container.addView(w, 0, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        ))

        val t = Tab(w, incognito)
        tabs.add(t)
        cur = tabs.size - 1
        if (url != null) {
            t.url = url
            w.loadUrl(url)
        }
        updateUi()
    }

    private fun closeTab(i: Int) {
        val t = tabs.removeAt(i)
        container.removeView(t.web)
        t.web.destroy()
        if (t.incognito && tabs.none { it.incognito }) wipeData()
        if (tabs.isEmpty()) {
            newTab(null, false)
            return
        }
        cur = minOf(i, tabs.size - 1)
        updateUi()
    }

    private fun updateUi() {
        tabs.forEachIndexed { i, t -> t.web.visibility = if (i == cur) View.VISIBLE else View.GONE }
        val t = tabs.getOrNull(cur) ?: return
        homeView.visibility = if (t.url.isEmpty()) View.VISIBLE else View.GONE
        if (!urlBar.hasFocus()) urlBar.setText(t.url)
        tabsBtn.text = tabs.size.toString()
    }

    private fun showTabs() {
        val names = tabs.mapIndexed { i, t ->
            (if (i == cur) "● " else "") + (if (t.incognito) "🕶 " else "") +
                (if (t.url.isEmpty()) "Yeni sekme" else t.title.ifBlank { t.url })
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Sekmeler (${tabs.size})")
            .setItems(names) { _, i -> cur = i; updateUi() }
            .setPositiveButton("Yeni sekme") { _, _ -> newTab(null, false) }
            .setNeutralButton("Sekmeyi kapat") { _, _ -> closeTab(cur) }
            .show()
    }

    // ---------- Menü ----------
    private fun showMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "Yeni sekme")
        m.menu.add(0, 2, 0, "Yeni gizli sekme")
        m.menu.add(0, 3, 0, "Ana sayfa")
        m.menu.add(0, 4, 0, "Yenile")
        m.menu.add(0, 5, 0, "Gece modu").apply { isCheckable = true; isChecked = nightMode }
        m.menu.add(0, 6, 0, "Reklam engelleyici").apply { isCheckable = true; isChecked = adBlock }
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> newTab(null, false)
                2 -> newTab(null, true)
                3 -> {
                    val t = tab()
                    t.url = ""
                    t.web.loadUrl("about:blank")
                    updateUi()
                }
                4 -> if (tab().url.isNotEmpty()) tab().web.reload()
                5 -> {
                    nightMode = !nightMode
                    tabs.forEach { t -> t.web.evaluateJavascript(if (nightMode) nightOn else nightOff, null) }
                }
                6 -> adBlock = !adBlock
            }
            true
        }
        m.show()
    }

    // ---------- Adres çubuğu ----------
    private fun go(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(" ") || !t.contains(".") -> "https://www.google.com/search?q=" + Uri.encode(t)
            else -> "https://$t"
        }
        val tb = tab()
        tb.url = url
        tb.web.loadUrl(url)
        urlBar.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
        updateUi()
    }

    // ---------- İndirme ----------
    private fun startDownload(url: String, ua: String?, cd: String?, mime: String?) {
        try {
            val req = DownloadManager.Request(Uri.parse(url))
            if (!mime.isNullOrEmpty()) req.setMimeType(mime)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            if (!ua.isNullOrEmpty()) req.addRequestHeader("User-Agent", ua)
            val name = URLUtil.guessFileName(url, cd, mime)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            Toast.makeText(this, "İndiriliyor: $name", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "İndirme başlatılamadı", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- Gizli mod ----------
    private fun wipeData() {
        CookieManager.getInstance().removeAllCookies(null)
        WebStorage.getInstance().deleteAllData()
        tabs.firstOrNull()?.web?.clearCache(true)
    }

    // ---------- Tam ekran video / geri tuşu ----------
    private fun hideCustom() {
        val v = customView ?: return
        (window.decorView as FrameLayout).removeView(v)
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }

    private fun onBack() {
        if (customView != null) { hideCustom(); return }
        val t = tab()
        when {
            t.web.canGoBack() -> t.web.goBack()
            tabs.size > 1 -> closeTab(cur)
            t.url.isNotEmpty() -> {
                t.url = ""
                t.web.loadUrl("about:blank")
                t.web.clearHistory()
                updateUi()
            }
            else -> finish()
        }
    }
}
